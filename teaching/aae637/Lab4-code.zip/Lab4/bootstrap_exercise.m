%% BOOTSTRAPPING EXERCISE 1  
% PROGRAM: Perform bootstrap examples
% AUTHOR:  Sarah Walker
% DATE:    February 19, 2014
% PURPOSE: conducts 3 bootstrapping examples to obtain standard errors from
% a regression. 1) Bootstrap OLS by residuals; 2) Bootstrap OLS by pairs;
% 3) Bootstrap NLS example from Assignment #1: Q1, before making assumptions on
% error structure.

%% Read in data & Calculate OLS SEs
clc; 
clear; 
[base_data,varnames,raw] = xlsread('c_50_00q_v2');
base_data                = sortrows(base_data,[1 2]); 
[t,k]                    = size(base_data);

RealGDP   = base_data(5:t,3);   
Cons      = base_data(1:(t-4),4);
Unemp     = base_data(4:(t-1),5);
RHS_names = char('Cons','Unemp');   
RHSvars   = horzcat(Cons,Unemp);
[t,k]     = size(RHSvars);
inter     = ones(t,1);
X         = log(RHSvars);
X         = horzcat(inter,X);
Y         = log(RealGDP);

% Calculate OLS SEs
beta    = inv(X'*X)*X'*Y;
sse     = sum((Y-beta(1)-X(:,2:3)*beta(2:3)).^2);
sig_2   = sse/(t-k);
std_err = sqrt(diag(sig_2*inv(X'*X)));

% Print OLS SEs 
ParNames={'Cons' 'Unemp'}';                              
estimates=horzcat(beta(2:3),std_err(2:3));                
header={'name' 'Estimate' 'std_error'};                  
disp('OLS etimates w/ intercept (intercept unshown)');   
print=partable(ParNames,estimates,header);               
               
%% Bootstrap OLS by residuals
beta_boot = zeros (1000,3); % place holder for bootstrapped betas

for B=1:1000
    B % Displays bootstrap iteration number
    
    % Setp 1.: Calculate e_i = y_i - X_i'Beta for each i
    e = Y - beta(1) - X(:,2:3)*beta(2:3);

    % Setp 2: Randomly draw t (num obs) values of e_i with replacement - e*_i
    e_resamp = randsample(e,t,true);

    % Step 3: Compute y*_i=X_i'Beta + e*_i
    y_star = beta(1) + X(:,2:3)*beta(2:3) + e_resamp;

    % Setp 4: Re-calculate Beta*
    b_star      = inv(X'*X)*X'*y_star;
    b_boot(B,:) = b_star';
    
    % Step 5: repeat 1-4 B times
end

    % Setp 6: Calculate the sample standard devation of betas
    b_boot_bar   = sum(b_boot)/B;
    b_boot_bar   = repmat(b_boot_bar,B,1);
    se_beta_boot = sqrt(sum((b_boot - b_boot_bar).^2)/(B-k));

% Print results for OLS and Bootstrap
ParNames  = {'Cons' 'Unemp'}';                              
estimates = horzcat(beta(2:3),std_err(2:3));                
header    = {'name' 'Estimate' 'std_error'};                  
disp('OLS estimates with OLS Std Err ');   
print     = partable(ParNames,estimates,header);  

ParNames  = {'Cons' 'Unemp'}';                              
estimates = horzcat(b_boot_bar(1,2:3)',se_beta_boot(2:3)');                
header    = {'name' 'Estimate' 'std_error'};                  
disp('Bootstrapped Std Err by Pairs');   
print    = partable(ParNames,estimates,header); 

%% Bootstrap OLS by Pairs
beta_boot = zeros (1000,3); % place holder for bootstrapped betas

for B=1:1000
    B % Displays bootstrap iteration number
    
    % Step 1. Randomly draw t (num obs) pairs of xi and yi with replacement
    index = randsample(200,t,true);
    pairs = horzcat(Y,X);
    
    for i=1:200 %Randomly select PAIRS of data, since 'randsample' only selects vectors
        pairs_boot(i,:) = pairs(index(i),:);
    end
    
    y_boot = pairs_boot(:,1);
    x_boot = pairs_boot(:,2:4);
    
    % Setp 2: calculate bootstrap betas (beta*) with sampled data   
    b_star      = inv(x_boot'*x_boot)*x_boot'*y_boot;
    b_boot(B,:) = b_star';
    
    % Step 3: repeat Step 1-2 B times
end  
  
    % Setp 4: Calculate the sample standard devation of betas
    b_boot_bar   = sum(b_boot)/B;
    b_boot_bar   = repmat(b_boot_bar,B,1);
    se_beta_boot = sqrt(sum((b_boot - b_boot_bar).^2)/(B-k));

% Print results for OLS and Bootstrap
ParNames  ={'Cons' 'Unemp'}';                              
estimates = horzcat(beta(2:3),std_err(2:3));                
header    = {'name' 'Estimate' 'std_error'};                  
disp('OLS estimates with OLS Std Err ');   
print     = partable(ParNames,estimates,header);  

ParNames  = {'Cons' 'Unemp'}';                              
estimates = horzcat(b_boot_bar(1,2:3)',se_beta_boot(2:3)');                
header    = {'name' 'Estimate' 'std_error'};                  
disp('Bootstrapped Std Err by Pairs');   
print     = partable(ParNames,estimates,header); 

%% Bootstrap NLS Using Pairs method when error structure unkown 
%  Uses Gaus Newton Algorithm for Betas estimation

b_boot = zeros(1000,2); % Place holder for bootstrapped betas

for B=1:1000;
  B % Displays bootstrap iteration
  
  % STEP 1. Randomly draw t (num obs) pairs of xi and yi with replacement
    index = randsample(200,t,true);
    pairs = horzcat(RealGDP,RHSvars);
    
    pairs_boot = zeros(200,3); 
    for i = 1:200; 
        pairs_boot(i,:)= pairs(index(i),:);
    end
    
    y_boot     = pairs_boot(:,1);
    cons_boot  = pairs_boot(:,2);
    unemp_boot = pairs_boot(:,3);
    x_boot     = horzcat(cons_boot,unemp_boot);
 
        
    % STEP 2. Find Betas via Gauss-Newton using OLS coefficients from new
    % sample as starting values
    b_start = inv(log(x_boot)'*log(x_boot))*log(x_boot)'*log(y_boot);
           
    global critic_limit iter_limit rhsvar numobs do_step func_name dh;
    rhsvar        = horzcat(cons_boot,unemp_boot);
    [numobs,numc] = size(rhsvar);
    parname2      = {'b_c','b_u'};
    critic_limit  = 10^-6;
    iter_limit    = 250;
    do_step       = 1;
    func_name     = ('procnl');
    dh            = 10^-6;

    [betas_nl,cov_nl ]= nls(b_start,y_boot,parname2);

    b_grid      = horzcat(betas_nl(1),betas_nl(2));
    b_boot(B,:) = b_grid;

    % STEP 3. Repeat Steps 1 and 2, B times
end
    % STEP 4. Calculate standard deviation of boostrap betas
    b_boot_bar   = sum(b_boot)/B;
    b_boot_bar   = repmat(b_boot_bar,B,1);
    se_beta_boot = sqrt(sum((b_boot - b_boot_bar).^2)/(B-k));


% Print NLS results with non-bootstrapped (i.e., original) sample using Gaus-Newton Numerical algorithm 
global critic_limit iter_limit rhsvar numobs do_step func_name dh;
rhsvar =horzcat(Cons,Unemp);
[numobs,numc]=size(rhsvar);
parname2={'b_c','b_u'};
critic_limit=10^-6;
iter_limit=250;
do_step=1;
func_name=('procnl');
dh=10^-6;

[betas_nl,cov_nl] = nls(b_start,RealGDP,parname2);

stbls     = sqrt(diag(cov_nl));
ParNames  = {'Cons' 'Unemp'}';                              
estimates = horzcat(betas_nl,stbls);                
header    = {'name' 'Estimate' 'std_error'};                  
disp('NLS estimates with NLS Err ');   
print     = partable(ParNames,estimates,header);  

% Print Bootstrap results
ParNames  = {'Cons' 'Unemp'}';                              
estimates = horzcat(b_boot_bar(1,:)',se_beta_boot');                
header    = {'name' 'Estimate' 'std_error'};                  
disp('Bootstrapped Std Err by Pairs');   
print    = partable(ParNames,estimates,header); 

