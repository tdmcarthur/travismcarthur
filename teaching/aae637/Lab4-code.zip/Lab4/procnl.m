%{
 ****************************************************************/
 *     Here is the procedure for defining nonlinear function    */
 *     for which you want to obtain paramater estimates         */
 ****************************************************************/
%}
function [nlfunc]= procnl(betas)
   global rhsvar;           % *** Way we pass the rhs matrix ***
                            % *** Non-linear Consumption function ***
   nlfunc=rhsvar(:,1).^betas(1).*rhsvar(:,2).^betas(2); 
end 