% AAE 637
% Lab 5
% 2/25/2015
% Travis McArthur


%% switch

which_algorithm = 'GN_plus_one';

switch which_algorithm
    case 'GN'
        display('Do GN')
        % Here should be code that actually involes the GN function
    case 'NR'
        display('Do NR')
    case 'GN_plus_one'
        display('Do GN then one more iter for NR')
    otherwise
        display('Must choose valid algorithm')
end

        

%% continue


for i= 1:10
    if ( i > 3 && i < 9)
        continue
    end
    display(i)
end

%% break

for i= 1:10
    if ( i > 3 && i < 9)
        break
    end
    display(i)
end

%% return

naive_factorial(200)

%% double logical symbols


1 > 2 && nonexistent_object > 0
% Evaluates to false and does not throw an error
1 > 2 &  nonexistent_object > 0
% Throws an error


1 < 2 || nonexistent_object > 0
1 < 2 |  nonexistent_object > 0
% Similar with double 'or'


test_mat = 1:10;
test_mat = test_mat(test_mat < 5 && test_mat > 2);
% Fails since subsetting matrices by && is invalid
test_mat = test_mat(test_mat < 5 & test_mat > 2);
% A-ok

%% producing an error

input = naive_factorial(-5);
input^2

%% try & catch


R_mat = [1 1 1 ; 
         2 2 2];
cov_mat = ones(2);

delta_cov = R_mat * cov_mat * R_mat';

try 
    delta_cov = R_mat * cov_mat * R_mat';
catch 
    delta_cov = R_mat' * cov_mat * R_mat;
    display('WARNING: R matrix automatically transposed')
end



%% The call stack
global critic_limit iter_limit rhsvar numobs do_step func_name dh lhsvar;
[base_data,varnames,raw] = xlsread('mizon_1977');  % read in the dataset

capital    = base_data(:,2);
labor_raw  = base_data(:,3);
unemployed = base_data(:,4);
hour       = base_data(:,5);
labor      =(labor_raw-unemployed).*hour/100;    % Don't forget that labor is calculated from total labor force minus the unemployed

lhsvar   = base_data(:,1);
func_name = ('cobb_douglas');
rhsvar    = horzcat(capital,labor);


[numobs,numc] = size(base_data);
parname_nr    = {'gamma','beta','alpha'};
critic_limit  = 10^-6;
iter_limit    = 250;
do_step       = 1;
dh            = 10^-6;
[betas_test,cov_test] = NR([1;1;1]', lhsvar, parname_nr);






%% restrict a parameter 


test_inv_tan(10^8, 5, 15)
% Yields 15
test_inv_tan(-10^8, 5, 15)
% Yields 5

%% Random number generation

rng(100)
% Set the random seed
unifrnd(0,1,5,1)
% Generate five values drawn from unif(0,1) distribution

%% Select matrix columns by name

urlwrite('http://www.aae.wisc.edu/aae637/data/matlab/gas_market_1_15.xlsx','temp.xlsx');
[full_data,varnames,raw]=xlsread('temp.xlsx', 'U.S. NG market data');

full_data(:, strcmp(varnames,'Year'))

pull_data(varnames,{'Total U.S. Gas Exp', 'Gas Price Index'}, full_data)
% pull_data() available at http://www.aae.wisc.edu/aae637/matlab_code/pull_data.m




























