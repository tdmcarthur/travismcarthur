function [ output ] = naive_factorial( factorial_num )
  if factorial_num <= 0 
      error('invalid input')
      display('invalid input')
  end
  output = 1;
  for i=2:factorial_num
      output = i * output ;
      if ~isfinite(output)
          return
      end
      i
  end
end

