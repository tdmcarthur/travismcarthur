function [ ret ] = test_inv_tan( beta, a, b )
    ret = atan(beta) * (b-a)/pi + (b+a)/2;
end

