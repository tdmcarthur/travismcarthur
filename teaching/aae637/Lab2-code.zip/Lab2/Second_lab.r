
install.packages(c("minpack.lm", "moments", "glmx", "systemfit", "MASS", "truncreg"))


## START NLS BIAS EXAMPLE

library("minpack.lm")
library("moments")


b0 <- 1.5
b1 <- 2

num.simulations <- 10000

set.seed(100)

num.obs.v <- c(50, 200)

normality.test.ls <- list()

par(mfrow=c(2,2))

for (num.obs in num.obs.v) {

  monte.carlo.ls <- vector("list",num.simulations )

  for ( i in 1:num.simulations) {
    x1 <- rnorm(num.obs)
    y <- b0 + (b1*x1)^b0 + rnorm(num.obs)
    result.nls <- nlsLM(y ~ b0 + (b1*x1)^b0, start=list(b0 = b0, b1 = b1), control = nls.lm.control(maxiter = 1024))
    monte.carlo.ls[[i]] <- coef(result.nls)
    cat("Simulation No.:", i, "\n")
  }

  results.df <-  as.data.frame(do.call(rbind, monte.carlo.ls))

  hist(results.df[, 1], 
      main = bquote(atop( paste("Mean of ", hat(beta[0]), ": " , 
        .(round(mean(results.df[, 1]), 4) ) ),
        paste( .(num.obs), " observations"))),
      xlab = bquote(paste("True ", beta[0], " = ", .(b0)))
  )
  
  
  hist(results.df[, 2], 
      main = bquote(atop( paste("Mean of ", hat(beta[1]), ": " , 
        .(round(mean(results.df[, 2]), 4) ) ),
        paste( .(num.obs), " observations"))),
      xlab = bquote(paste("True ", beta[1], " = ", .(b1)))
  )
  
  normality.test.ls[[length(normality.test.ls)+1]] <- jarque.test(results.df[, 1])
  names(normality.test.ls)[length(normality.test.ls)] <- 
    paste0("Beta_0; No. obs: ", num.obs )
  normality.test.ls[[length(normality.test.ls)+1]] <- jarque.test(results.df[, 2])
  names(normality.test.ls)[length(normality.test.ls)] <- 
    paste0("Beta_1; No. obs: ", num.obs )

}

par(mfrow=c(1,1))

normality.test.ls


# START JENSEN'S INEQUALITY

par(mar=c(5, 6, 4, 2) + 0.1)

plot(x=seq(0.9, 2.1, .01), y=(seq(0.9, 2.1, .01))^4, type="l", lty=1, col="blue",
  ylab="", xlab="", main="Jensen's inequality")

lines(c(1, 2), (c(1,2))^4, lty=1, col="red")

points(c(1, 2), (c(1,2))^4)

lines(c(1.5, 1.5), c(0, mean(c(1,2)^4)), lty=2, col="red")

lines(c(1.5, 1.5), c(0, mean(c(1,2))^4), lty=2, col="blue")

lines(c(0, 1.5), c(mean(c(1,2)^4), mean(c(1,2)^4)), lty=2, col="red")

lines(c(0, 1.5), c(mean(c(1,2))^4, mean(c(1,2))^4), lty=2, col="blue")

mtext("E[g(X)]", side = 2, at = mean(c(1,2)^4), las=1, line=2.5, col="red")
mtext("g(E[X])", side = 2, at = mean(c(1,2))^4, las=1, line=2.5, col="blue")

par(mar=c(5, 4, 4, 2) + 0.1)




# START SEEMINGLY UNRELATED REGRESSIONS VARIANCE EXAMPLE

library("systemfit")
library("MASS")

intercept <- 1
b1 <- 1.5
b2 <- 2
b3 <- 1
b4 <- 0.5

num.obs <- 100

set.seed(100)

x1 <- rnorm(num.obs)
x2 <- rnorm(num.obs)
x3 <- rnorm(num.obs)

Sigma <- matrix(c(1, 0.75, 0.75, 1), 2, 2)
err.term.mat <- mvrnorm(n=num.obs, rep(0, 2), Sigma * 5)

y1 = intercept + b1*x1 + b2*x2 + err.term.mat[, 1]
y2 = intercept + b3*x1 + b4*x3 + err.term.mat[, 2]

formula <- list(y1 ~ x1 + x2, y2 ~ x1 + x3)

system.OLS <- systemfit( formula, method = "OLS")
system.SUR <- systemfit( formula, method = "SUR", control = systemfit.control( maxiter=100 ))

ci.results.df <- rbind(
 cbind(coef=coef(system.OLS), confint(system.OLS) ),
 cbind(coef=coef(system.SUR), confint(system.SUR) )
)

ci.results.df <- as.data.frame(ci.results.df)

ci.results.df$coef.names <- c(names(coef(system.OLS)), names(coef(system.SUR)))
ci.results.df$fit <- c(rep("OLS", length(coef(system.OLS))), rep("SUR", length(coef(system.SUR))))
rownames(ci.results.df) <- 1:nrow(ci.results.df)

library(ggplot2)

ggplot(ci.results.df, aes(x=coef.names, y=coef, colour=fit)) + 
    geom_errorbar(position=position_dodge(width=0.9), aes(ymin=`2.5 %`, ymax=`97.5 %`), width=.2) +
    geom_line() +
    geom_point(position=position_dodge(width=0.9))







# START HETEROSKEDASTIC PROBIT INCONSISTENCY EXAMPLE

library("glmx")

set.seed(100)
n <- 100000
x1 <- rnorm(n)
x2 <- rnorm(n)

intercept <- 1
b1 <- 2
b2 <- 3

ystar <- intercept + b1*x1 + b2*x2 + rnorm(n, sd = exp(x1+x2))
y <- factor(ystar > 0)

homosk.fit <- glm(y ~ x1 + x2, family = binomial(link = "probit"))
heterosk.fit <- hetglm(y ~ x1 + x2, family = binomial(link = "probit"))

model.comparison <- cbind(`true value`=c(intercept = intercept, b1=b1, b2=b2, `(scale)_x1`=1, `(scale)_x2`=1), 
  `homoskedastic fit` = round(c(coef(homosk.fit), NA, NA), 4),
  `heteroskedastic fit` = round(coef(heterosk.fit), 4)
)

model.comparison




## START NLS ASYMPTOTIC NORMALITY EXAMPLE


b0 <- 1.5
b1 <- 2

num.simulations <- 10000

set.seed(100)

num.obs.v <- c(50, 5000)

normality.test.ls <- list()

par(mfrow=c(2,2))

for (num.obs in num.obs.v) {

  monte.carlo.ls <- vector("list",num.simulations )

  for ( i in 1:num.simulations) {
    x1 <- rnorm(num.obs)
    y <- b0 + (b1*x1)^b0 + rnorm(num.obs)
    result.nls <- nlsLM(y ~ b0 + (b1*x1)^b0, start=list(b0 = b0, b1 = b1), control = nls.lm.control(maxiter = 1024))
    monte.carlo.ls[[i]] <- coef(result.nls)
    cat("Simulation No.:", i, "\n")
  }

  results.df <-  as.data.frame(do.call(rbind, monte.carlo.ls))

  hist(results.df[, 1], 
      main = bquote(atop( paste("Mean of ", hat(beta[0]), ": " , 
        .(round(mean(results.df[, 1]), 4) ) ),
        paste( .(num.obs), " observations"))),
      xlab = bquote(paste("True ", beta[0], " = ", .(b0)))
  )
  
  
  hist(results.df[, 2], 
      main = bquote(atop( paste("Mean of ", hat(beta[1]), ": " , 
        .(round(mean(results.df[, 2]), 4) ) ),
        paste( .(num.obs), " observations"))),
      xlab = bquote(paste("True ", beta[1], " = ", .(b1)))
  )
  
  normality.test.ls[[length(normality.test.ls)+1]] <- jarque.test(results.df[, 1])
  names(normality.test.ls)[length(normality.test.ls)] <- 
    paste0("Beta_0; No. obs: ", num.obs )
  normality.test.ls[[length(normality.test.ls)+1]] <- jarque.test(results.df[, 2])
  names(normality.test.ls)[length(normality.test.ls)] <- 
    paste0("Beta_1; No. obs: ", num.obs )

}

par(mfrow=c(1,1))

normality.test.ls





# START TRUNCATED REGRESSION ROBUSTNESS EXAMPLE


library("truncreg")

set.seed(100)

n.obs <- 1000000

intercept <- 1
b1 <- 1.5

x <- rnorm(n.obs)

y <- intercept +  b1 * x + runif(n.obs, -5, 5)
xt <- x[y>0]
yt <- y[y>0]

trunc.unif <- truncreg(yt ~ xt)


#summary(trunc.unif)


y <- intercept +  b1 * x + rnorm(n.obs, sd=sd(runif(n.obs, -5, 5)))
xt <- x[y>0]
yt <- y[y>0]


trunc.normal <- truncreg(yt ~ xt)

#summary(trunc.normal)

model.comparison <- cbind(`True value`=c(intercept = intercept, b1=b1, sigma=sd(runif(n.obs, -5, 5))), 
  `Uniform error term` = round(coef(trunc.unif), 4),
  `Normal error term` = round(coef(trunc.normal), 4)
)

model.comparison








