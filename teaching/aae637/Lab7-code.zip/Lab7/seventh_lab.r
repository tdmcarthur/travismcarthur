work.dir <- ""
# Put working directory above

n.obs <- 50
set.seed(100)
x <- runif(n.obs)

b_1 <- 3
b_2 <- (-5)

y <- 2 + b_1 * x + b_2 * x^2 + rnorm(n.obs)

x.pred <- seq(min(x), max(x), length.out=1000)
y.true <- 2 + b_1 * x.pred + b_2 * x.pred^2 

pdf(paste0(work.dir, "2nd_degree_model_fit.pdf"), width=4.5, height=4.5)

poly.degree <- 2

fit.lm <- lm(y ~ poly(x, poly.degree))
summary(fit.lm)

plot(x, y, main=paste0("Polynomial degree of fitted model: ", poly.degree))

lines(x.pred, predict( fit.lm, newdata=data.frame(x=x.pred)), col="blue")
lines(x.pred, y.true, lty=2, col="red")
legend("bottomleft", legend=c("True model", "Fitted model"), lty=2:1, col=c("red", "blue"))

dev.off()



pdf(paste0(work.dir, "10th_degree_model_fit.pdf"), width=4.5, height=4.5)

poly.degree <- 10

fit.lm <- lm(y ~ poly(x, poly.degree))
summary(fit.lm)

plot(x, y, main=paste0("Polynomial degree of fitted model: ", poly.degree))
lines(x.pred, predict( fit.lm, newdata=data.frame(x=x.pred)), col="blue")
lines(x.pred, y.true, lty=2, col="red")
legend("bottomleft", legend=c("True model", "Fitted model"), lty=2:1, col=c("red", "blue"))

dev.off()



