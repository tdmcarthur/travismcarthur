

pdf(file = "Chi-sq-plot.pdf", 
  width=4, height=4)


plot.range <- 10

deg.free <- 1
alpha <- 0.05
one.minus.alpha <- 1 - alpha

curve(dchisq(x, df=deg.free), 0, plot.range, 
  main=bquote(paste(chi[.(deg.free)]^2, " distribution")),
  xlab="Value of Wald statistic",
  ylab="Density")
  

polygon(c(0, seq(.01, qchisq(one.minus.alpha, df=deg.free), .01), qchisq(one.minus.alpha, df=deg.free)), 
  c(0, dchisq(seq(.01,qchisq(one.minus.alpha, df=deg.free), .01), df=deg.free), 0), col="red")


polygon(c(qchisq(one.minus.alpha, df=deg.free), seq(qchisq(one.minus.alpha, df=deg.free), 100, .01), 0), 
  c(0, dchisq(seq(qchisq(one.minus.alpha, df=deg.free), 100, .01), df=deg.free), 0), col="lightblue")


legend(x="topright", 
  legend=c(paste0(one.minus.alpha*100, "% of mass"), 
    paste0(alpha*100, "% of mass")), 
  fill = c("red", "lightblue"))


dev.off()




B.jac <- matrix(c(1/1.5, -.5/(1.5^2),
  0,2*1.5), ncol=2, byrow=TRUE)

V <- matrix(c(1, -0.5, -0.5, 2), ncol=2, byrow=TRUE)

V.fn.hat <- B.jac %*% V %*% t(B.jac)

transformed.B <- matrix(c(.5/1.5, 1.5^2), ncol=1)

restr <- matrix(c(1, 2), ncol=1)
#restr <- matrix(c(.5/1.5, 2), ncol=1)

wald.result <- 
  t(transformed.B - restr) %*% solve(V.fn.hat) %*% (transformed.B - restr)

1 - pchisq(wald.result, df=length(restr))

