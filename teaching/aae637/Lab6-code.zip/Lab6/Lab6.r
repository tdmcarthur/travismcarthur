#install.packages("nortest")
library("nortest")



set.seed(100)

M <- 10000

results.df <- data.frame(Shapiro.Wilk=rep(NA, M), Kolmogorov.Smirnov=rep(NA, M))

for ( i in 1:M) {
  data.vec <- rlnorm(100, meanlog = 0, sdlog = .25)
  results.df$Shapiro.Wilk[i] <- shapiro.test(data.vec)$p.value < 0.05
  results.df$Kolmogorov.Smirnov[i] <- lillie.test(data.vec)$p.value < 0.05
}


cat("Probability of rejecting the null when it is false:\n")
colMeans(results.df)








results.df <- data.frame(Shapiro.Wilk=rep(NA, M), Kolmogorov.Smirnov=rep(NA, M))

for ( i in 1:M) {
  data.vec <- rnorm(5000, mean = 0, sd= .25)
  results.df$Shapiro.Wilk[i] <- shapiro.test(data.vec)$p.value < 0.05
  results.df$Kolmogorov.Smirnov[i] <- lillie.test(data.vec)$p.value < 0.05
  # The maximum likelihood estimates for mean and variance, assuming a normal distn,
  # are just the sample mean and variance.
}



cat("Probability of rejecting the null when it is true:\n")
colMeans(results.df)




