function [ ret ] = own_elast( betas )
    global elast_mean
    beta = betas(2);
    lambda = betas(4);
    x = elast_mean;
    ret = beta .* x.^lambda;
end

