
% Code below will not work, since variables are not assigned in right order

some_formula_result = A + B';

A = X * y; 
B = max(X);

X = rand(4);
y = (1:4)';

% Code below works

X = rand(4);
y = (1:4)';

A = X * y; 
B = max(X);

some_formula_result = A + B';




% Delta Method


global elast_mean
elast_mean = mean(rhsvar(:, 1));
% Compute the mean values of the prices above

first_elast = own_elast(betas_boxcox);
% Obtain the actual values of the elasticity

first_elast_grad = Grad(betas_boxcox, 'own_elast', 1);
% Compute the gradient of the own_elast() function at the
% point of the estimated betas

first_V_hat = first_elast_grad * cov_boxcox * first_elast_grad' ;
% Perform the delta method calculation 

w_test_output = (first_elast + 1)' * first_V_hat^-1 * (first_elast + 1);
% Compute the Wald statistic, where null hypothesis is that the elasticity
% is equal to -1
  
w_test_p_val = 1 - chi2cdf(w_test_output, 1);
% Obtain the p-value







