%% Lab 1 companion code
%% Travis McArthur (1/28/2015)

clear;					               % Command to clear memory 
clc;                                   % Command to clear the command window

%% Numerical precision

2 - (sqrt(2))^2

% Application to maximum likelihood
n_obs = 100;

likelihood_value = unifrnd(0, 1, n_obs, 1);

prod(likelihood_value)
sum(log(likelihood_value))

likelihood_value = unifrnd(0, 1, n_obs, 1) + 1;

prod(likelihood_value)
sum(log(likelihood_value))

% Loss of precision

big_num = 10^20;
big_num = big_num + 10^6;
big_num - 10^20
% "should be" 10^6

1.2 - 0.2 - 1 
1.2 - 1 - 0.2 
% Floating point arithmatic is not even commutative


%% Unmask the hidden state

desired_obs = 1000;
y = cumsum([0;randn(desired_obs,1)],1);
% Create random walk, which is AR(1)

[estimated_coef, estimated_varcov] = autoregression(y, 5);

estimated_coef


%% Function handles

simple_deriv(@ex_func, 2)


%% Code execution efficiency

x = 0;

tic
for i=1:100000
  x = horzcat(x, randn(1));
end
toc

x = repmat(0, 100000, 1);

tic
for i=1:100000
  x(i) = randn(1);
end
toc

% Note: this is a toy example. Don't fill a matrix with random numbers this
% way


%% Global variables

global h
h = 10^-7;

simple_deriv(@ex_func, 2)
