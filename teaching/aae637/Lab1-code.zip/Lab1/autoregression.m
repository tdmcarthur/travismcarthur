function[bls,covb]=autoregression(x, num_lags)  
%  Function take a vector x and creates a matrix of num_lags lags

  design_mat = make_lags(x, num_lags) ;
  % Create the design matrix
  
  param_names = strcat(repmat({'lag'}, num_lags, 1), num2str((1:num_lags)'));
  % Create parameter names to feed into the OLS estimation function

  [bls,covb]=basic_ols_proc(design_mat, x, param_names, 0);
  % x((num_lags+1):end, :)

end

