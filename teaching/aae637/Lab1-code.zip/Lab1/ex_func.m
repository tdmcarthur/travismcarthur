function [ ret ] = ex_func( x )
  ret = (x.^2 - sin(x)).^2;
end

