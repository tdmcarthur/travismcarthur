function[lagged_data]=make_lags(x, num_lags) 
%  Function take a vector x and creates a matrix of num_lags lags

   [numr,numc]=size(x);   
   assert(numc==1); 
   % assert() will stop the program if a specified condition is false                   
   
   lagged_data = zeros(numr - num_lags, num_lags);
   % Pre-allocate matrix
   
   for i=1:num_lags
       lagged_data(:, i) = x( (num_lags-i+1):(numr-i), :) ;
   end

end
   
