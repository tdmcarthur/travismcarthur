function [ ret ] = simple_deriv( func, point )
    h = 0.0000001;
    % h is the "epsilon" step length    
    ret = (func(point+h) - func(point))/h;
end

